<!--
 * WYM editor : what you see is What You Mean web-based editor
 * Copyright (c) 1997-2006, H.O.net - http://www.honet.be/
 * Use of WYM editor is granted by the terms of the MIT License (http://www.opensource.org/licenses/mit-license.php).
 *
 * For further information visit:
 * 		http://www.wym-editor.org/
 *
 * File Name:
 *		readme.txt
 *		Readme.
 *		See the documentation for more info.
 *
 * File Authors:
 * 		Jean-Francois Hovinne (jf.hovinne@wym-editor.org)
 *
 * File Revision:
 *		$Id: readme.txt,v 1.2 2006/01/31 08:45:45 jf_hovinne Exp $
-->

WYM editor documentation is available online at http://www.wym-editor.org/