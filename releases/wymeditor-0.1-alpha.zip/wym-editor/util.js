/*
 * WYM editor : what you see is What You Mean web-based editor
 * Copyright (c) 1997-2005, H.O.net - http://www.honet.be/
 * Use of WYM editor is granted by the terms of the MIT License (http://www.opensource.org/licenses/mit-license.php).
 *
 * For further information visit:
 * 		http://www.wym-editor.org/
 * 
 * File Name:
 *		util.js
 *		Javascript utilities.
 *		See the documentation for more info.
 * 
 * File Authors:
 * 		Jean-Francois Hovinne (jf.hovinne@wym-editor.org)
 *
 * File Revision:
 *		$Id: util.js,v 1.3 2005/10/07 13:49:49 jf_hovinne Exp $
*/

function sTrim(sText)
{
	return(lTrim(rTrim(sText)));
}

function lTrim(sText)
{
	while(sText.charAt(0)==" "){sText=sText.substr(1,sText.length)}
	return(sText);
}

function rTrim(sText)
{
	while(sText.charAt(sText.length-1)==" "){sText=sText.substr(0,sText.length-1)}
	return(sText);
}

function insertAt(sText,sInserted,iPos)
{
	return(sText.substr(0,iPos)+sInserted+sText.substring(iPos,sText.length));
}

//very basic html cleanup
//currently, closes unclosed tags and add missing double-quotes (for attributes) (bad msie behaviours)
function cleanupHTML(sHtml)
{
	var flagTag=false,begTag=false;flagAttr=false,begAttr=false,unclosed=false,unquoted=false,tag="",ret="";
	
	for(x=0;x<sHtml.length;x++)
	{
		c=sHtml.charAt(x);
		if(begTag)
		{
			if(c==" " || c==">")
			{
				switch(tag.toLowerCase())
				{
					case "br":
					case "img":
					case "hr":
					case "input":
					case "link":
					case "base":
					case "basefont":
					case "col":
					case "frame":
					case "isindex":
					case "meta":
					case "param":
						unclosed=true;
						break;
					default:
						unclosed=false;
						break;	
				}
				tag="";
				begTag=false;
			}
			else tag+=c;
		}
		
		if(c=="<"){begTag=true;flagTag=true;}
		if(c==">" && unclosed){c=" />";}
		
		if(begTag)ret+=c.toLowerCase();
		
		else if(flagTag)
		{
			if(flagAttr)
			{
				if(begAttr)
				{
					if(c!="\""){ret+="\""+c;unquoted=true;begAttr=false;}
					else{ret+=c;unquoted=false;begAttr=false;}
				} 
				else if(c==" " || c==">" || c==" />")
				{
					if(unquoted)
					{
						if(sHtml.charAt(x-1)!="\""){ret+="\""+c;flagAttr=false;}
						else ret+=c;
					}
					else ret+=c;
				}
				else if(c=="\""){ret+=c;flagAttr=false;}
				else ret+=c;
			}
			else if(c=="="){begAttr=true;flagAttr=true;ret+=c;}
			else ret+=c.toLowerCase();
			
			if(c==">" || c==" />")
			{
				flagTag=false;
				flagAttr=false;
			}
		}	
		else ret+=c;
	}
	return(ret);
}