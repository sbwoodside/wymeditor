WYMeditor.SKINS['minimal'] = {
    //placeholder for the skin JS, if needed

    //init the skin
    //wym is the WYMeditor.editor instance
    init: function(wym) {
        //do something
    }
};
